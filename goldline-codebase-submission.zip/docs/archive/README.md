# Archived & aspirational documentation

These files are kept for **team history**, design exploration, or hackathon planning. They may describe **PWA**, **sql.js**, **14k POIs**, or **production** language that **does not match** the shipped native app.

**Before citing Goldline to judges or reviewers, read [CANON.md](../CANON.md).**

---

## Superseded architecture narratives

| Doc | Why archived |
|-----|----------------|
| [GOLDLINE_MASTER_BRIEF.md](../GOLDLINE_MASTER_BRIEF.md) | Written for PWA-first plan; native Expo is P0 |
| [site/GOLDLINE_MASTER_BRIEF.md](../site/GOLDLINE_MASTER_BRIEF.md) | Static site copy of brief |
| [GOLDLINE_* plans](../GOLDLINE_FINAL_IMPLEMENTATION_PLAN.md) | Pre-rebrand Goldline era |
| [GOLDLINE_*_IMPLEMENTATION_PLAN.md](../GOLDLINE_FINAL_IMPLEMENTATION_PLAN.md) | Multi-week plans; partial execution |

## Design & process artifacts (still useful internally)

| Doc | Purpose |
|-----|---------|
| [GOLDLINE_MASTER_ENCYCLOPEDIA.md](../GOLDLINE_MASTER_ENCYCLOPEDIA.md) | Feature encyclopedia |
| [superpowers/specs/](../superpowers/specs/) | Design specs per phase |
| [superpowers/plans/](../superpowers/plans/) | Implementation plans |
| [design/](../design/) | Stitch prompts & refs |

## Active (not archived)

- [CANON.md](../CANON.md) · [ARCHITECTURE.md](../ARCHITECTURE.md) · [SUBMISSION.md](../SUBMISSION.md)
- [JUDGE_START_HERE.md](../../JUDGE_START_HERE.md) · [FIELD_TEST.md](../FIELD_TEST.md)
- [START_TRIAGE_MEDICAL_REVIEW.md](../START_TRIAGE_MEDICAL_REVIEW.md) · [VOICE_CLASSIFIER_EVAL.md](../VOICE_CLASSIFIER_EVAL.md)

Do **not** delete archived docs without team review — link to CANON instead.
