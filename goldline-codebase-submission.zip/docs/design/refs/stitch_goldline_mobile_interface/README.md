# Historical Stitch export (pre-Goldline)

These HTML files are **archived Stitch reference exports** from the Goldline-era mobile UI. The shipped app uses the **Goldline** Care Path design system (`goldline-mobile/DESIGN.md`). Do not treat titles or colors here as current product branding.
