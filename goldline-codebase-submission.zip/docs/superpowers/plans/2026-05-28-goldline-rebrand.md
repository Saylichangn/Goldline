# Goldline rebrand — implementation plan index

> **Status:** Implemented 2026-05-28  
> **Design spec:** [../specs/2026-05-28-goldline-rebrand-design.md](../specs/2026-05-28-goldline-rebrand-design.md)

## Summary

Full product rebrand from Goldline to **Goldline** with Care Path tokens, `com.goldline.app`, brand module (TDD), component rename `Nova*` → `Goldline*`, splash revamp, monorepo doc updates, and GitHub-facing doc/banner sweep.

## Verification

```bash
cd goldline-mobile
npm run typecheck
npm test
npm run verify:docs
npm run verify:branding
```

## Doc sweep (2026-05-28)

- [x] `GOLDLINE_*` judge docs → `GOLDLINE_*` with redirect stubs
- [x] Banners (`banner.svg`, `banner-light.svg`) + PNG render
- [x] `docs/site` build pipeline + `goldline-complete.html` + redirect from `goldline-complete.html`
- [x] `verify-public-branding.mjs` + CI hook
- [x] [GOLDLINE_MASTER_ENCYCLOPEDIA.md](../../GOLDLINE_MASTER_ENCYCLOPEDIA.md) index

Native rebuild: `npx expo prebuild --clean` then `npx expo run:android`.
