# Goldline — master encyclopedia (judge & team index)

**Status:** v1.5.0-goldline-rebrand shipped (2026-05-28)  
**Product:** **Goldline** — offline-first Golden Hour co-pilot (IIT Madras RoadSoS 2026)  
**Repo:** [github.com/Saylichangn/goldline](https://github.com/Saylichangn/goldline) (slug unchanged)  
**Tagline:** *When signal drops, the path still holds.*

This file is the **navigation hub** for all judge-facing documentation after the Goldline rebrand. Deep narrative lives in [GOLDLINE_MASTER_BRIEF.md](./GOLDLINE_MASTER_BRIEF.md).

---

## Quick links

| Resource | Path / URL |
|----------|------------|
| Root README | [README.md](../README.md) |
| Submission checklist | [SUBMISSION.md](./SUBMISSION.md) |
| Architecture | [ARCHITECTURE.md](./ARCHITECTURE.md) |
| Live brief site | [roadsafetyhackathon-six.vercel.app](https://roadsafetyhackathon-six.vercel.app) |
| Complete UI brief (HTML) | [goldline-complete.html](https://roadsafetyhackathon-six.vercel.app/margi-complete.html) |
| Mobile app README | [goldline-mobile/README.md](../goldline-mobile/README.md) |
| Design system | [goldline-mobile/DESIGN.md](../goldline-mobile/DESIGN.md) |
| Changelog | [CHANGELOG.md](../CHANGELOG.md) |
| Version history | [VERSION_HISTORY.md](./VERSION_HISTORY.md) |
| Rebrand release notes | [release-notes-goldline-rebrand.md](../release-notes-goldline-rebrand.md) |

---

## Brand & native identifiers

| Item | Value |
|------|--------|
| Display name | Goldline |
| Care Path primary | Royal blue `#0056b3` |
| Care Path urgent | Orange `#ff8c00` |
| Android package | `com.goldline.app` |
| URL scheme | `goldline://` |
| GHP SMS header | `GOLDLINE GHP` |
| GHP hash prefix | `mg-` |
| QR envelope | `ND1:` (unchanged for relay compatibility) |

## Legacy compatibility

Older packets and demos may still show `GOLDLINE GHP` in SMS bodies. The mobile app accepts both `GOLDLINE GHP` and `GOLDLINE GHP` headers when parsing (`LEGACY_GHP_HEADERS` in `goldline-mobile/src/lib/brand.ts`). Internal storage keys remain `nd_*` by design.

---

## Judge documentation map (renamed 2026-05-28)

| Document | Purpose |
|----------|---------|
| [GOLDLINE_MASTER_BRIEF.md](./GOLDLINE_MASTER_BRIEF.md) | Full team narrative, flows, demo script |
| [GOLDLINE_FINAL_IMPLEMENTATION_PLAN.md](./GOLDLINE_FINAL_IMPLEMENTATION_PLAN.md) | Build spec §1–20, TDD rules |
| [GOLDLINE_REFINEMENT_PLAN.md](./GOLDLINE_REFINEMENT_PLAN.md) | UI refinement phases R1–R9 |
| [GOLDLINE_STITCH_FINAL_IMPLEMENTATION_PLAN.md](./GOLDLINE_STITCH_FINAL_IMPLEMENTATION_PLAN.md) | Stitch → app integration |
| [GOLDLINE_V2_IMPLEMENTATION_PLAN.md](./GOLDLINE_V2_IMPLEMENTATION_PLAN.md) | Post-hackathon roadmap |
| [GOLDLINE_TEAM_GUIDE.html](./GOLDLINE_TEAM_GUIDE.html) | Printable team guide |
| [site/goldline-complete.html](./site/goldline-complete.html) | Complete UI + project brief (HTML) |
| [site/GOLDLINE_COMPLETE_UI_BRIEF.html](./site/GOLDLINE_COMPLETE_UI_BRIEF.html) | UI-focused brief export |

**Redirects:** Former `GOLDLINE_*` paths have short stubs pointing here or to the `GOLDLINE_*` files above.

---

## Monorepo layout

```
goldline-mobile/     # P0 — Expo SDK 54, Goldline Care Path UI
goldline/            # Next.js web mirror (optional demo)
docs/                 # Plans, GOLDLINE_* briefs, site → Vercel
scripts/              # Banner render, POI ingest, doc sweep
data/                 # Generated SQLite (gitignored)
```

---

## Safety lanes (product)

1. **Golden Hour** — Drive mode → trip → HUD → START triage → trauma routing → GHP → QR relay → 108 SMS when online.
2. **Naari Shakti** — Gender-gated women's portal → hold emergency → distress HUD + SMS composer.

Specs: [2026-05-23-naari-shakti-design.md](./superpowers/specs/2026-05-23-naari-shakti-design.md) · Stitch prompt [naari-shakti-portal.md](./design/stitch-prompts/naari-shakti-portal.md)

---

## Verification commands

```bash
cd goldline-mobile
npm run typecheck
npm test
npm run verify:docs
npm run verify:branding
```

Public copy must not contain `Goldline` / `GOLDLINE` except in [VERSION_HISTORY.md](./VERSION_HISTORY.md) commit archaeology and historical Stitch refs under `docs/design/refs/`.

---

## Assets & banners

| Asset | Path |
|-------|------|
| GitHub banner (dark) | `docs/assets/banner.svg` → `banner.png` |
| GitHub banner (light) | `docs/assets/banner-light.svg` → `banner-light.png` |
| Regenerate PNGs | `node scripts/render-banner.mjs` |
| Store icons | See `goldline-mobile/assets/GOLDLINE_ASSETS.md` |

---

## AI / agent workflow

See [AGENTS.md](./AGENTS.md). Rebrand implementation plan: [superpowers/plans/2026-05-28-goldline-rebrand.md](./superpowers/plans/2026-05-28-goldline-rebrand.md).

---

*Team Goldline · IIT Madras Road Safety Hackathon 2026 · Goldline v1.5.0*
